---
layout: default
collection: capsule-review
title: ''
slug: item-138
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

PAINTED FIRE
Kwon-taek (2002)

He painted her like a swan
and then left to see the swans. 
"This is a farewell".
