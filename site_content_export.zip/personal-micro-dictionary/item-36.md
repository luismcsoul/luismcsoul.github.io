---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-36
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

ANTICIPATION:

One thousand
mini death sentence flyers,
suddenly released
in your bloodstream.
