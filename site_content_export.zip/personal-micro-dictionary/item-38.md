---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-38
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

BODYBUILDER:

She wears her skin.
