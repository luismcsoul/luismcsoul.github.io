---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-40
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

EINSTEIN
(hindrance):

Una piedra en el camino.
