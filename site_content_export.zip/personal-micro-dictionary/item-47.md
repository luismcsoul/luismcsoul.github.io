---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-47
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

CANIS MAJOR:

Collective Unconsciousness,
the headless robot dog
from Black Mirror.
