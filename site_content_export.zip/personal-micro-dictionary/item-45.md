---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-45
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

VERTEBRAE:

Column,
Rows,
Data.
