---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-37
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

ASSESSMENT:

The way dogs 
get to know 
each other.
