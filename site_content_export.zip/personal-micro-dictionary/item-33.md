---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-33
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

BUILDING:

A cuboid mount
with caves.

Eagle view
but termite passages.

Cave humans
nevertheless.
