---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-41
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

PLANTS:

Under Earth as it is in Heaven,
except you
phytoplankton,
you're a drifter.
