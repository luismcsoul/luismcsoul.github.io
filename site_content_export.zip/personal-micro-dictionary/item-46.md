---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-46
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

INTELLIGENCE:

Inversely proportionate
to the amount of trash
you leftover.
