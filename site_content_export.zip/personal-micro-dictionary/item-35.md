---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-35
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

INNER EAR:

A living fossil
inside a sea of humans.
