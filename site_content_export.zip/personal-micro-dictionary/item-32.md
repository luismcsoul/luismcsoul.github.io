---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-32
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

NEWBORN GAZE:

The universe
recognizing itself.
