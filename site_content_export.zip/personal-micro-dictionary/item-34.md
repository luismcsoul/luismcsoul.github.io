---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-34
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

PENCIL:

Ashes reincarnating
as new life
on a paper.
