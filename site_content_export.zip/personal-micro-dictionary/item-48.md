---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-48
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

SPIRIT:

When the animal stops,
hallucinates.
