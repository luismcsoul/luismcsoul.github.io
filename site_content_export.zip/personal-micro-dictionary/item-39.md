---
layout: default
collection: personal-micro-dictionary
title: ''
slug: item-39
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

SOCIAL MEDIAS:

Memories
pixel
decaying.
