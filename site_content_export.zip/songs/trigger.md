---
layout: default
collection: songs
title: Trigger
slug: trigger
schema_type: MusicComposition
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: Emotional triggers, Hot buttons, Emotional flooding, perpetual problems,
  reactive cycle, attachment injuries, threats
album: Counterfeit
---

TRIGGER

Pain, has many names,
emotions attached to piercing memories.
Releasing free radicals,
scenes from the past that grow present spikes.

Trigger, triggers
a word away from shouting,
trigger the animal,
we're actively endorsing tragedies.

Bigger triggers, triggers everywhere,
unable to stop the escalating mess,
bigger triggers and reasons to ignite.
Rage hiddes behind every other thing.

Don't wait "for the pain to make sense".
