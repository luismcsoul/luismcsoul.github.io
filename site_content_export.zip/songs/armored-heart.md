---
layout: default
collection: songs
title: Armored Heart
slug: armored-heart
schema_type: MusicComposition
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: emotional withdrawal, emotional numbing, emotional detachment, emotional
  blunting, pistanthrophobia, avoidant attachment, behavioral walls, behavioral guarding
album: Counterfeit
---

ARMORED HEART

If you were hurt,
it's natural for you to close
your doors/a practical distrust,
in a tendency to load yourself
with weapongs and 
Armored heart!

Nothing personal, I'm trying my best
but I can't get attached to anything
hurting people in snowball effect
I'm sorry you meet me in decadence.

There's not only one version of ourselves,
I'm sorry you meet this creepy and lame:
Armored Heart


