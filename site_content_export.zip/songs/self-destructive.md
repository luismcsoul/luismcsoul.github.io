---
layout: default
collection: songs
title: Self-Destructive
slug: self-destructive
schema_type: MusicComposition
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: self-destructive behavior, obsessive-compulsive disorder, hoarding disorder
album: Animal
---

SELF-DESTRUCTIVE

Your portraits are getting outdated
in the social network you used to check yourself.
And it will be pointless,
that you got minions of followers robots.

Your anxiety to get every time more,
the skin of the world will dissolve.
Obsessive compulsive disorder:
Self-destructive behavior.

You rip off the land, 
exploit and kill living beings of all kinds.
Desperate for the latest collectibles,
accumulating you will not fill your existencial emptyness.
