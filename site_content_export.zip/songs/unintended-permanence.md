---
layout: default
collection: songs
title: Unintended Permanence
slug: unintended-permanence
schema_type: MusicComposition
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: Collateral
---

UNINTENDED PERMANENCE

Every character need to be shaken
so we can prove: it was worth both lives (yours and mine)
The protagonist, prone to agony,
always bets against the odds.

If something is not breaking
you are not trying hard enough

Bring me turbulence,
unintended permanence,
Abracadabra,
Rocket Engine Explosion.

It's the flat[screen]-continuum that hurts!

No Absolute Zero,
No smooth solution,
No Deus ex Machina (No bail out)
Real Deal.

The uneventful hours, compound against you!

Would all this third party damage subdue?
