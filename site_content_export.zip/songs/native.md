---
layout: default
collection: songs
title: Native
slug: native
schema_type: MusicComposition
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: monocultures, monotony, standarization
album: Collateral
---

NATIVE

Monocultures monotonize-us,
the educative and labor system
would like to standardize you!
But what you really need is flexibility,
because your mission is to be:
A Native Forest!
