---
layout: default
collection: taglines
title: Our Way
slug: our-way
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

Let's play it 
our way
so we can cheat.
