---
layout: default
collection: taglines
title: ''
slug: item-20
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

Don't wait 
"for the pain to make sense"
