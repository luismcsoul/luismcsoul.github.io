---
layout: default
collection: taglines
title: ''
slug: item-96
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: zero-follower, no followers
album: ''
---

Wish to have no followers
