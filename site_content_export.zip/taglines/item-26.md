---
layout: default
collection: taglines
title: ''
slug: item-26
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

A basketball's free throw
never lies.
