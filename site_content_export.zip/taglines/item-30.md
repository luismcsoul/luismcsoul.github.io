---
layout: default
collection: taglines
title: ''
slug: item-30
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

If the audience is too big,
nothing important
is being discussed.
