---
layout: default
collection: taglines
title: To Paradise
slug: to-paradise
schema_type: Statement
keywords: []
excerpt: ''
media_hero: https://miro.medium.com/v2/resize:fit:1400/1*Kz6OlNxFTbTXXgglBMdzsA.jpeg
media_alt: Puppeteer Walid Rashed performing for kids on top of the ruins of the city.
  Saraqib, Syria. March 27, 2019. Photograph by Anas Alkharbouti/DPA (Deutsche Picture
  Alliance)
taglines: ''
references: ''
album: ''
---

To paradise 
we don't arrive, 
we awake.
