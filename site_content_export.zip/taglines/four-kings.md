---
layout: default
collection: taglines
title: Four Kings
slug: four-kings
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

They were
four kings,
but one
got lost.
