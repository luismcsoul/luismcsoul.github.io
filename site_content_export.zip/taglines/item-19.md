---
layout: default
collection: taglines
title: ''
slug: item-19
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

A house is not a home,
if you are not welcome.
