---
layout: default
collection: taglines
title: ''
slug: item-13
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

In the living room
I have now
the toys I didn't have
as a kid.
