---
layout: default
collection: taglines
title: ''
slug: item-28
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

Wish
that the person 
who loves you,
never becomes
invisible to you.
