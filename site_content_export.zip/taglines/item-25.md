---
layout: default
collection: taglines
title: ''
slug: item-25
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

Deliver us
from anything
we would like
to collect.
