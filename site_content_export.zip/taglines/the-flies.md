---
layout: default
collection: taglines
title: The Flies
slug: the-flies
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

The flies 
know 
where is
my wound.
