---
layout: default
collection: taglines
title: ''
slug: item-23
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

Messenger
and Message
are One
