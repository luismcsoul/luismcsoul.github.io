---
layout: default
collection: taglines
title: ''
slug: item-21
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

A missing piece,
makes obsolete
the table game.
