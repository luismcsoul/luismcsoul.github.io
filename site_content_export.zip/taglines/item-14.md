---
layout: default
collection: taglines
title: ''
slug: item-14
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

Two seconds ago
this river wasn't here.
