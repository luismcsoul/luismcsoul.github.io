---
layout: default
collection: taglines
title: Behind
slug: behind
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

Behind
every evil woman,
there's a big
asshole.
