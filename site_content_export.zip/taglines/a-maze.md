---
layout: default
collection: taglines
title: A Maze
slug: a-maze
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: amazing, maze
album: ''
---

Amazing
always
has a maze
inside.
