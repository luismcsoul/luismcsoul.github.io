---
layout: default
collection: taglines
title: Revenge trading
slug: revenge-trading
schema_type: CreativeWork
keywords:
- revenge
- trading
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: revenge trading
album: ''
---

Revengeful trading,
our lives.
