---
layout: default
collection: taglines
title: A Battery
slug: a-battery
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

A battery
increases his size
in order to
attract a female
counterpart.
