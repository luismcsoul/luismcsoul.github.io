---
layout: default
collection: taglines
title: ''
slug: item-16
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

During starry nights, 
remember always to spot
the darkest patch.
