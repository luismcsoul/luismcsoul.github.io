---
layout: default
collection: taglines
title: Where He Died
slug: where-he-died
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

In the place 
where he died,
a mountain arises.
