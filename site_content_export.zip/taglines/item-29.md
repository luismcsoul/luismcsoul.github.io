---
layout: default
collection: taglines
title: ''
slug: item-29
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

Symmetry
is mirrored
code
