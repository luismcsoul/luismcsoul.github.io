---
layout: default
collection: taglines
title: ''
slug: item-18
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

For the photon,
we are still photography.
