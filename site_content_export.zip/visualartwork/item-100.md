---
layout: default
collection: visualartwork
title: ''
slug: item-100
schema_type: VisualArtwork
keywords: []
excerpt: ''
media_hero: https://media.raribleuserdata.com/image/aHR0cHM6Ly9pcGZzLnJhcmlibGV1c2VyZGF0YS5jb20vaXBmcy9RbVNFR1pITHBKZlV4WkUzRUpUTDdwbThWRkZKV2FLZG9XM0NTZ0RqdHhBbW01L2ltYWdlLnBuZw==?
media_alt: ''
taglines: ''
references: ''
album: ''
---

Golden Snub-Nosed Monkey
