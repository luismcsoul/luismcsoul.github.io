---
layout: default
collection: visualartwork
title: ''
slug: item-98
schema_type: VisualArtwork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: surveillance capitalism, attention economy, dystopian dissimulation
album: ''
---

Google is searching us
