---
layout: default
collection: visualartwork
title: ''
slug: item-99
schema_type: VisualArtwork
keywords: []
excerpt: ''
media_hero: https://media.raribleuserdata.com/image/aHR0cHM6Ly9pcGZzLnJhcmlibGV1c2VyZGF0YS5jb20vaXBmcy9RbVN0S0s5ZGlDcXVoeFBBUFlkZXl3OXhXUmJWaVhuR2ZzdXhhN0JLdnNUbjhCL2ltYWdlLnBuZw==?
media_alt: ''
taglines: ''
references: ''
album: ''
---

New Britain Mask
