---
layout: default
collection: visualartwork
title: ''
slug: item-108
schema_type: VisualArtwork
keywords: []
excerpt: ''
media_hero: https://media.raribleuserdata.com/image/aHR0cHM6Ly9pcGZzLnJhcmlibGV1c2VyZGF0YS5jb20vaXBmcy9RbWRHeUJuNW9haVlHNFdRRjdaUWZFWlE0VmQzQ3k1M1BXUkpYaU5rbUFrUXZZL2ltYWdlLnBuZw==?
media_alt: ''
taglines: ''
references: ''
album: ''
---

Sepik River Mask
