---
layout: default
collection: photograph
title: Lossing weight
slug: lossing-weight
schema_type: Photograph
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

Lossing weight
