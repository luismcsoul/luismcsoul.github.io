---
layout: default
collection: sculpture
title: ''
slug: item-117
schema_type: Sculpture
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: Takotsubo Cardiomyopathy, broken heart, chicken heart
album: ''
---

Chicken Heart
