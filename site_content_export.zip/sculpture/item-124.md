---
layout: default
collection: sculpture
title: ''
slug: item-124
schema_type: Sculpture
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: labyrith, Minotaur, Crete, thalassocracy, Minoan civilization
album: ''
---

Under the reign of king Minos
