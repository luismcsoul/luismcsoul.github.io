---
layout: default
collection: sculpture
title: ''
slug: item-119
schema_type: Sculpture
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: Antoine de Saint-Exupéry, The Little Prince
album: ''
---

VISIBLE TO ME

"What is essential is invisible to the eye"
