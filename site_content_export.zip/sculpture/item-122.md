---
layout: default
collection: sculpture
title: ''
slug: item-122
schema_type: Sculpture
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: Corazón espinado, Santana, Supernatural
album: ''
---

Corazón Espinado
