---
layout: default
collection: written-photography
title: ''
slug: item-50
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

IN THE RIVER

All stones are rounded by time.
those still sharp,
just went through a breakup.
