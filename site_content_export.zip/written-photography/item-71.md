---
layout: default
collection: written-photography
title: ''
slug: item-71
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

YOUR SALARY

is still
a certain 
amount
of salt.
