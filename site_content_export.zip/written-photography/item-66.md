---
layout: default
collection: written-photography
title: ''
slug: item-66
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

FROM RED TO GREEN

There are 
millions of steps 
between.
