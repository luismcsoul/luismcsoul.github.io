---
layout: default
collection: written-photography
title: ''
slug: item-88
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

TRANSCENDENTAL

Imaginary Time
is
Impossible to Square
