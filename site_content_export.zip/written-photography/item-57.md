---
layout: default
collection: written-photography
title: ''
slug: item-57
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

INFINITY

From this perspective
infinity
is just a dot.
