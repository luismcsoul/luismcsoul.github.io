---
layout: default
collection: written-photography
title: ''
slug: item-81
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

DOWN IN THE HORIZON

Sirius blinks red, white and blue,
like the lights
on a police car.
