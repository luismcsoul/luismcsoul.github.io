---
layout: default
collection: written-photography
title: ''
slug: item-70
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

I'M FULL OF SUPERSTITION

as scientificaly backed
as possible.
