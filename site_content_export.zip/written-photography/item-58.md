---
layout: default
collection: written-photography
title: ''
slug: item-58
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

EVERY NUMBER

Every number is 
invisibly
multiplied, divided and powered
by one.
