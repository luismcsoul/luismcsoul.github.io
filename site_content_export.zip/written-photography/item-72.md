---
layout: default
collection: written-photography
title: ''
slug: item-72
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

SEAMLESSLY

Wherever you see 
a waiting line,

frictionless solutions
are coming.
