---
layout: default
collection: written-photography
title: ''
slug: item-89
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

"I" BEARS THE SHADOW

The sun dances
Saggitarius A*
<=>
