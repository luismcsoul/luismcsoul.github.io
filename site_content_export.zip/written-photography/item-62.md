---
layout: default
collection: written-photography
title: ''
slug: item-62
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

A CHINESE EMPEROR

died
precisely because of
his belief in drinking mercury
as an elixir towards immortality.
