---
layout: default
collection: written-photography
title: ''
slug: item-79
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

DEEP SLEEP

Requires
that you put on the face
of a dead person.
