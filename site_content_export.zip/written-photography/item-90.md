---
layout: default
collection: written-photography
title: ''
slug: item-90
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

MOUNTAINS

Are destroyed
to tear down the axis mundi
of a colonized community.
