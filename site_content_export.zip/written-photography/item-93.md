---
layout: default
collection: written-photography
title: ''
slug: item-93
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

OUR MEMORIES

Are being overwritten
by someone else now.
