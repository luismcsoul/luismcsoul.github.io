---
layout: default
collection: written-photography
title: ''
slug: item-77
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

MIND WHERE YOU ARE

Convergent evolution
is operating on you.
