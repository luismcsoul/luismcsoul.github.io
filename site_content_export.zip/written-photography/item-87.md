---
layout: default
collection: written-photography
title: ''
slug: item-87
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

COMMIT

Humans 'will not longer commute',
neither 'they will communicate'
They will just 'commit'.
