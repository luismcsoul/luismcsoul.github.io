---
layout: default
collection: written-photography
title: ''
slug: item-73
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

I KNOW ABOUT HAPPINESS

Because 
I felt your laughter
like my own.
