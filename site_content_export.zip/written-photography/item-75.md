---
layout: default
collection: written-photography
title: ''
slug: item-75
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

IN A CASINO

I lost everything
that I ever
considered valuable.
