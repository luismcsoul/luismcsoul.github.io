---
layout: default
collection: written-photography
title: ''
slug: item-74
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

COUNTERINTUITIVE

Removing temptations
by eating them all.
