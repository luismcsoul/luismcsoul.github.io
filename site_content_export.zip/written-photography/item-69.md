---
layout: default
collection: written-photography
title: ''
slug: item-69
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

SISYPHUS SYZIGY

Each one of us 
carries the Earth underneath
from perihelion to aphelion
over and over again
relay races
symphony.
