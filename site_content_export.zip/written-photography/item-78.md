---
layout: default
collection: written-photography
title: ''
slug: item-78
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

IKARIA WARIOOTIA

Inside of us all,
mount to anus,
we're sophisticated worms
with physiological crutches.

Peristaltic Locomotion.
