---
layout: default
collection: written-photography
title: ''
slug: item-80
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

BY THE CUT

See you
where
the two dead ends
meet.
