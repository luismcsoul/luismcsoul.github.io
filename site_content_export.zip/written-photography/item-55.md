---
layout: default
collection: written-photography
title: ''
slug: item-55
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

SLEEPING BAG

This anaconda,
almost entirely,
has devored me.
