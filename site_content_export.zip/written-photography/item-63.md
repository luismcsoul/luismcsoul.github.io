---
layout: default
collection: written-photography
title: ''
slug: item-63
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

EVERYWHERE I LOOK

"The Masque of the Red Death"
