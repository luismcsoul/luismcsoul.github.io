---
layout: default
collection: written-photography
title: ''
slug: item-59
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

THE BACTERIA

Inside our guts
configure a smart organism,
we are just its shell.

Human-Shaped Exoskeleton
