---
layout: default
collection: written-photography
title: ''
slug: item-60
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

LOOK AROUND

All metal, glass, plastic and concrete,
together with their 
colored coatings,
have been cooked for you.

No wondering why
human-made
climate change.
