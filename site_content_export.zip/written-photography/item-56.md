---
layout: default
collection: written-photography
title: ''
slug: item-56
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

THE SLAVES

Were finally free
when the archaeologist
unearthed that clay
and pronounced their names.
