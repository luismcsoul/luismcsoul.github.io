---
layout: default
collection: written-photography
title: ''
slug: item-54
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

WEIGHT

After scanning the whole store 
looking for unique craftsmanship,

the price of the jewelry 
was entirely determined 
by the weight of the gold.
