---
layout: default
collection: written-photography
title: ''
slug: item-61
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

ORCHESTRA

Groups of women 
have started to transform
every single monument
into a hole in the ground,
flattened and circular,
called 'Dancing Space'.
