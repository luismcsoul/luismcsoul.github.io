---
layout: default
collection: written-photography
title: ''
slug: item-51
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

GRAVE MARKERS

With only full names
and two dates,
should have at least
one more sentence to tell. 
