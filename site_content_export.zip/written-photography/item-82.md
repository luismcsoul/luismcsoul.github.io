---
layout: default
collection: written-photography
title: ''
slug: item-82
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

SUCCESSOR

Depends on
the ability
to succeed.
