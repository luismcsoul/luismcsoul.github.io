---
layout: default
collection: written-photography
title: ''
slug: item-86
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

TAO

Mistery and Mastery
are twins,

they both 
meet 
in the mist.
