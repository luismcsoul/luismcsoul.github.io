---
layout: default
collection: written-photography
title: ''
slug: item-83
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

THE CELLS

That could understand
everything that we now know,

hadn't born yet
by the time
we heard the same advices.
