---
layout: default
collection: written-photography
title: ''
slug: item-91
schema_type: Statement
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

SHARING THE SAME DNA

We are all subjects to
variable degrees of
Mad Cow Disease.
