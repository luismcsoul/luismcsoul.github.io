---
layout: default
collection: written-photography
title: ''
slug: item-64
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

A SMALL TIE

Is a perfect coat
for your sternum. 
