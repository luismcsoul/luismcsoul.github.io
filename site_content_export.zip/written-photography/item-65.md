---
layout: default
collection: written-photography
title: ''
slug: item-65
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

SANS-SOUCI

"Care-free"
is a cursed palace
in Haiti.
