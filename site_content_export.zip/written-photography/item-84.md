---
layout: default
collection: written-photography
title: ''
slug: item-84
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

YOU CAN'T GO BACK IN TIME

But you can move forward
to the future's past 
of other person.

By showing up:
you change it.
