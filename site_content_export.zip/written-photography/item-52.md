---
layout: default
collection: written-photography
title: ''
slug: item-52
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

CINDERELLA

Goes to sleep
before midnight,
because she is another 
representation 
of Venus 
