---
layout: default
collection: written-photography
title: ''
slug: item-85
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

ONCE I SAT DOWN

In Zen Meditation.

Since then I got the feeling
that I'm still sitting there

and you're seeing
a hologram.
