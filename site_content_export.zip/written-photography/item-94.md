---
layout: default
collection: written-photography
title: ''
slug: item-94
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

THE ANTS CAME

and took away,  
one by one,
the binary codes
of this book. 
