---
layout: default
collection: written-photography
title: ''
slug: item-53
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

PROPORTIONAL

Followers of shiny things
are directly proportional
devotees of darkness. 
