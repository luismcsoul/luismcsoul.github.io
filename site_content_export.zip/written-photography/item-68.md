---
layout: default
collection: written-photography
title: ''
slug: item-68
schema_type: ShortStory
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

IN THE TEMPLE

Days of endless mantras
until people faint healed.
