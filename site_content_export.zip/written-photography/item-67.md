---
layout: default
collection: written-photography
title: ''
slug: item-67
schema_type: CreativeWork
keywords: []
excerpt: ''
media_hero: ''
media_alt: ''
taglines: ''
references: ''
album: ''
---

BITCOIN WAS THE TEST NET

For a further 
energetic demand
from a Matrix.
